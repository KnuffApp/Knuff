//
//  MGSFragariaFontsAndColoursPrefsViewController.h
//  Fragaria
//
//  Created by Jonathan on 14/09/2012.
//
//

#import <Cocoa/Cocoa.h>

@interface MGSFragariaFontsAndColoursPrefsViewController : NSViewController

- (IBAction)setFontAction:(id)sender;
- (void)changeFont:(id)sender;
@end
